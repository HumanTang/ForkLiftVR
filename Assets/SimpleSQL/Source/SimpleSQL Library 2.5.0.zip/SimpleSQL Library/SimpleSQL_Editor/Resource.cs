﻿using UnityEngine;
using UnityEditor;
using System;
using System.Reflection;
using System.IO;

namespace SimpleSQL
{
    static public class Resource
    {
        static public Texture2D platformMacOSiOS_Off;
        static public Texture2D platformMacOSiOS_On;
        //static public Texture2D platformAndroid9_Off;
        //static public Texture2D platformAndroid9_On;
        static public Texture2D platformUniversal_Off;
        static public Texture2D platformUniversal_On;
        static public Texture2D platformAndroid_Off;
        static public Texture2D platformAndroid_On;

        static public Texture2D systemData_Off;
        static public Texture2D systemData_On;
        static public Texture2D noSystemData_Off;
        static public Texture2D noSystemData_On;

        static public void LoadTextures()
        {
            LoadTexture(ref platformMacOSiOS_Off, "Platform_MacOS_iOS_Off.png", 100, 100);
            LoadTexture(ref platformMacOSiOS_On, "Platform_MacOS_iOS_On.png", 100, 100);

            //LoadTexture(ref platformAndroid9_Off, "Platform_Android9_Off.png", 100, 100);
            //LoadTexture(ref platformAndroid9_On, "Platform_Android9_On.png", 100, 100);

            LoadTexture(ref platformUniversal_Off, "Platform_Universal_Off.png", 100, 100);
            LoadTexture(ref platformUniversal_On, "Platform_Universal_On.png", 100, 100);

            LoadTexture(ref platformAndroid_Off, "Platform_Android_Off.png", 100, 100);
            LoadTexture(ref platformAndroid_On, "Platform_Android_On.png", 100, 100);

            LoadTexture(ref systemData_Off, "SystemData_Off.png", 100, 100);
            LoadTexture(ref systemData_On, "SystemData_On.png", 100, 100);

            LoadTexture(ref noSystemData_Off, "NoSystemData_Off.png", 100, 100);
            LoadTexture(ref noSystemData_On, "NoSystemData_On.png", 100, 100);
        }

        static public void LoadTexture(ref Texture2D texture, string resourceName, int width, int height)
        {
            if (texture == null)
            {
                texture = new Texture2D(width, height, TextureFormat.ARGB32, false);

                Stream myStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("SimpleSQL.Resources." + resourceName);

                if (myStream != null)
                {
                    texture.LoadImage(ReadToEnd(myStream));
                    myStream.Close();
                }
                else
                {
                    Debug.LogError("Missing Dll resource: " + resourceName);
                }
            }
        }

        static private byte[] ReadToEnd(System.IO.Stream stream)
        {
            long originalPosition = 0;

            if (stream.CanSeek)
            {
                originalPosition = stream.Position;
                stream.Position = 0;
            }

            try
            {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }
    }
}
