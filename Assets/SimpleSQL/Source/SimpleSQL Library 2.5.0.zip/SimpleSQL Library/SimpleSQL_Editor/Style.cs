using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace SimpleSQL
{
    static public class Style
    {

        static private Stack<Color> _colorStack;
        static private Stack<Color> _backgroundColorStack;

        static private Texture2D _yellowTexture;
        static private Texture2D _green1Texture;
        static private Texture2D _green2Texture;
        static private Texture2D _grey1Texture;
        static private Texture2D _grey2Texture;
        static private Texture2D _grey3Texture;
        static private Texture2D _grey4Texture;
        static private Texture2D _grey5Texture;
        static private Texture2D _grey6Texture;
        static private Texture2D _grey7Texture;
        static private Texture2D _grey8Texture;
        static private Texture2D _grey9Texture;

        static public Color Yellow;
        static public Color Black;
        static public Color White;
        static public Color Green1;
        static public Color Green2;
        static public Color Grey1;
        static public Color Grey2;
        static public Color Grey3;
        static public Color Grey4;
        static public Color Grey5;
        static public Color Grey6;
        static public Color Grey7;
        static public Color Grey8;
        static public Color Grey9;

        static public GUIStyle warningStyle;
        static public GUIStyle SQLTableHeaderStyle;
        static public GUIStyle SQLTableAlternatingHeaderStyle;
        static public GUIStyle SQLTableRowStyle;
        static public GUIStyle SQLTableAlternatingRowStyle;
        static public GUIStyle noBorderButtonStyle;
        static public GUIStyle optionBorderStyle;


        static public void Reset()
        {
            CreateStacks();

            Black = new Color(0, 0, 0);
            Yellow = new Color(0.98f, 1.0f, 0.61f);
            White = new Color(1.0f, 1.0f, 1.0f, 1.0f);
            Green1 = new Color(0.8f, 1.0f, 0.8f);
            Green2 = new Color(0.6f, 1.0f, 0.6f);
            Grey1 = new Color(0.1f, 0.1f, 0.1f);
            Grey2 = new Color(0.2f, 0.2f, 0.2f);
            Grey3 = new Color(0.3f, 0.3f, 0.3f);
            Grey4 = new Color(0.4f, 0.4f, 0.4f);
            Grey5 = new Color(0.5f, 0.5f, 0.5f);
            Grey6 = new Color(0.6f, 0.6f, 0.6f);
            Grey7 = new Color(0.7f, 0.7f, 0.7f);
            Grey8 = new Color(0.8f, 0.8f, 0.8f);
            Grey9 = new Color(0.9f, 0.9f, 0.9f);

            SetTexture(ref _yellowTexture, Yellow);
            SetTexture(ref _green1Texture, Green1);
            SetTexture(ref _green2Texture, Green2);
            SetTexture(ref _grey1Texture, Grey1);
            SetTexture(ref _grey2Texture, Grey2);
            SetTexture(ref _grey3Texture, Grey3);
            SetTexture(ref _grey4Texture, Grey4);
            SetTexture(ref _grey5Texture, Grey5);
            SetTexture(ref _grey6Texture, Grey6);
            SetTexture(ref _grey7Texture, Grey7);
            SetTexture(ref _grey8Texture, Grey8);
            SetTexture(ref _grey9Texture, Grey9);

            SetStyle(ref warningStyle, ref _yellowTexture, Black);
            SetStyle(ref SQLTableHeaderStyle, ref _green1Texture, Black);
            SetStyle(ref SQLTableAlternatingHeaderStyle, ref _green2Texture, Black);
            SetStyle(ref SQLTableRowStyle, ref _grey8Texture, Black);
            SetStyle(ref SQLTableAlternatingRowStyle, ref _grey9Texture, Black);
            SetStyle(ref optionBorderStyle, ref _grey3Texture, White);

            if (noBorderButtonStyle == null)
            {
                noBorderButtonStyle = new GUIStyle();
            }
            noBorderButtonStyle.margin = new RectOffset(0, 0, 0, 0);
            noBorderButtonStyle.padding = new RectOffset(0, 0, 0, 0);
        }

        static private void CreateStacks()
        {
            if (_colorStack == null)
                _colorStack = new Stack<Color>();

            if (_backgroundColorStack == null)
                _backgroundColorStack = new Stack<Color>();
        }

        static public void SetStyle(ref GUIStyle style, ref Texture2D texture, Color foregroundColor)
        {
            SetStyle(ref style, ref texture, foregroundColor, 10, TextAnchor.MiddleCenter, false, 2);
        }

        static public void SetStyle(ref GUIStyle style, ref Texture2D texture, Color foregroundColor, int fontSize, TextAnchor textAnchor)
        {
            SetStyle(ref style, ref texture, foregroundColor, fontSize, textAnchor, false, 2);
        }

        static public void SetStyle(ref GUIStyle style, ref Texture2D texture, Color foregroundColor, int fontSize, TextAnchor textAnchor, bool wordWrap, int yOffset)
        {
            if (style == null)
            {
                style = new GUIStyle();
            }

            style.normal.background = texture;
            style.fontSize = fontSize;
            style.normal.textColor = foregroundColor;
            style.alignment = textAnchor;
            style.wordWrap = wordWrap;
            style.padding = new RectOffset(2, 4, yOffset, 2);
        }

        static public void SetTexture(ref Texture2D texture, Color backgroundColor)
        {
            if (texture == null)
            {
                texture = new Texture2D(1, 1, TextureFormat.ARGB32, false);
            }

            texture.SetPixel(0, 1, backgroundColor);
            texture.Apply();
        }

        static public Color GetStyleBackgroundColor(GUIStyle style)
        {
            if (style == null)
                return Color.black;

            if (style.normal.background == null)
                return Color.black;

            return style.normal.background.GetPixel(1, 1);
        }

        static public void PushBackgroundColor(GUIStyle style)
        {
            PushBackgroundColor(GetStyleBackgroundColor(style));
        }

        static public void PushBackgroundColor(Color c)
        {
            CreateStacks();
            _backgroundColorStack.Push(GUI.color);
            GUI.backgroundColor = c;
        }

        static public void PopBackgroundColor()
        {
            GUI.backgroundColor = _backgroundColorStack.Pop();
        }

        static public void PushColor(GUIStyle style)
        {
            PushColor(GetStyleBackgroundColor(style), 1.0f);
        }

        static public void PushColor(GUIStyle style, float brightnessFactor)
        {
            PushColor(GetStyleBackgroundColor(style), brightnessFactor);
        }

        static public void PushColor(Color c)
        {
            PushColor(c, 1.0f);
        }

        static public void PushColor(Color c, float brightnessFactor)
        {
            CreateStacks();
            _colorStack.Push(GUI.color);
            Color c2 = new Color(c.r * brightnessFactor, c.g * brightnessFactor, c.b * brightnessFactor, c.a);
            GUI.color = c2;
        }

        static public void PopColor()
        {
            GUI.color = _colorStack.Pop();
        }
    }
}